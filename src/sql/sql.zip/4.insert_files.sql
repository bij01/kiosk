insert into FILES values (FILE_SEQ.nextval, 111, 'coffee1_americano' ,'png');
insert into FILES values (FILE_SEQ.nextval, 112, 'coffee2_cafelatte' ,'png');
insert into FILES values (FILE_SEQ.nextval, 113, 'coffee3_vanilla' ,'png');
insert into FILES values (FILE_SEQ.nextval, 114, 'coffee4_cappuccino' ,'png');
insert into FILES values (FILE_SEQ.nextval, 115, 'coffee5_cafemoca' ,'png');
insert into FILES values (FILE_SEQ.nextval, 116, 'coffee6_caramel macchiato' ,'png');
insert into FILES values (FILE_SEQ.nextval, 117, 'coffee7_whitechcolatemoca' ,'png');
insert into FILES values (FILE_SEQ.nextval, 118, 'coffee8_mintmoca','png');
insert into FILES values (FILE_SEQ.nextval, 119, 'coffee9_espresso','png');

insert into FILES values (FILE_SEQ.nextval, 120, 'coffee10_espressoconpanna', 'png');
insert into FILES values (FILE_SEQ.nextval, 121, 'coffee11_espressomacchiato', 'png');
insert into FILES values (FILE_SEQ.nextval, 122, 'coffee12_condensedmilkcafelatte', 'png');
insert into FILES values (FILE_SEQ.nextval, 123, 'coffee13_coldbrewlatte', 'png');
insert into FILES values (FILE_SEQ.nextval, 124, 'coffee14_coldbrewwhitevianna', 'png');
insert into FILES values (FILE_SEQ.nextval, 125, 'coffee15_coldbrewnitro','png');
insert into FILES values (FILE_SEQ.nextval, 126, 'coffee16_coldbrewamericano','png');

insert into FILES values (FILE_SEQ.nextval, 221, 'beverage1_grapefruitade', 'png');
insert into FILES values (FILE_SEQ.nextval, 222, 'beverage2_lemonade' ,'png');
insert into FILES values (FILE_SEQ.nextval, 223, 'beverage3_limeade', 'png');
insert into FILES values (FILE_SEQ.nextval, 224, 'beverage4_greengrapeade', 'png');
insert into FILES values (FILE_SEQ.nextval, 225, 'beverage5_sunsetpunch', 'png');
insert into FILES values (FILE_SEQ.nextval, 226, 'beverage6_oceanpunch', 'png');
insert into FILES values (FILE_SEQ.nextval, 227, 'beverage7_sunrisepunch', 'png');
insert into FILES values (FILE_SEQ.nextval, 228, 'beverage8_originshake', 'png');
insert into FILES values (FILE_SEQ.nextval, 229, 'beverage8_originshake', 'png');
insert into FILES values (FILE_SEQ.nextval, 230, 'beverage10_strawberryshake', 'png');
insert into FILES values (FILE_SEQ.nextval, 231, 'beverage11_affogato', 'png');
insert into FILES values (FILE_SEQ.nextval, 232, 'beverage12_affogatocoldbrewmoca', 'png');
insert into FILES values (FILE_SEQ.nextval, 233, 'beverage13_grapefruitorange' ,'png');
insert into FILES values (FILE_SEQ.nextval, 234, 'beverage14_pomegranateapplelimetea' ,'png');
insert into FILES values (FILE_SEQ.nextval, 235, 'beverage15_lemontea' ,'png');
insert into FILES values (FILE_SEQ.nextval, 236, 'beverage16_milktea', 'png');

insert into FILES values (FILE_SEQ.nextval, 331, 'desert1_plainwaffle' ,'png');
insert into FILES values (FILE_SEQ.nextval, 332, 'dessert2_honeycaramelbread' ,'png');
insert into FILES values (FILE_SEQ.nextval, 333, 'dessert3_pretzle' ,'png');
insert into FILES values (FILE_SEQ.nextval, 334, 'dessert4_creamcheese' ,'png');
insert into FILES values (FILE_SEQ.nextval, 335, 'dessert5_plainbagle' ,'png');
insert into FILES values (FILE_SEQ.nextval, 336, 'dessert6_gwakamollisaendeuwichi' ,'png');
insert into FILES values (FILE_SEQ.nextval, 337, 'dessert7_macalong' ,'png');
insert into FILES values (FILE_SEQ.nextval, 338, 'dessert8_tiramisucake' ,'png');
insert into FILES values (FILE_SEQ.nextval, 339, 'dessert9_cheesecake' ,'png');
insert into FILES values (FILE_SEQ.nextval, 340, 'dessert10_chocolatebrownie' ,'png');

commit;
